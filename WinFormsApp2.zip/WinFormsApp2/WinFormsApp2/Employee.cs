﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WinFormsApp2
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void binddata()
        {
            SqlCommand cmd1 = new SqlCommand("Select Employee_ID,Employee_Name,Employee_Contactno,Employee_Address, Employee_Salary,Starting_Date from Employee", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.SelectCommand = cmd1;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);
        }
        SqlConnection conn = new SqlConnection("Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true ");
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Employee_Load(object sender, EventArgs e)
        {
            binddata();
            search1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Insert into Employee(Employee_ID,Employee_Name,Employee_Contactno,Employee_Address, Employee_Salary,Starting_Date)Values (@Employee_ID,@Employee_Name,@Employee_Contactno,@Employee_Address, @Employee_Salary,@Starting_Date)", conn);
            cmd2.Parameters.AddWithValue("Employee_ID", textBox1.Text);
            cmd2.Parameters.AddWithValue("Employee_Name", textBox2.Text);
            cmd2.Parameters.AddWithValue("Employee_Contactno", textBox3.Text);
            cmd2.Parameters.AddWithValue("Employee_Address", textBox4.Text);
            cmd2.Parameters.AddWithValue("Employee_Salary", textBox5.Text);
            cmd2.Parameters.AddWithValue("Starting_Date", textBox6.Text);
            cmd2.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd3 = new SqlCommand("update Employee Set Employee_Name='" + textBox2.Text + "',Employee_Contactno='" + textBox3.Text + "',Employee_Address='" + textBox4.Text + "',Employee_Salary='" + textBox5.Text + "',Starting_Date='" + textBox6.Text + "' where Employee_ID='" + textBox1.Text + "'", conn);
            cmd3.ExecuteNonQuery();
            conn.Close();
            binddata();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("Delete from Employee where Employee_ID=@Employee_ID", conn);
            cmd4.Parameters.AddWithValue("Employee_ID", textBox1.Text);
            cmd4.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;
            DataGridViewRow selectedrow = dataGridView1.Rows[index];
            textBox1.Text = selectedrow.Cells[0].Value.ToString();
            textBox2.Text = selectedrow.Cells[1].Value.ToString();
            textBox3.Text = selectedrow.Cells[2].Value.ToString();
            textBox4.Text = selectedrow.Cells[3].Value.ToString();
            textBox5.Text = selectedrow.Cells[4].Value.ToString();
            textBox6.Text = selectedrow.Cells[5].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /* SqlCommand cmd1 = new SqlCommand("SELECT * FROM Employee WHERE Employee_ID = @Employee_ID OR Employee_Name LIKE '%' + @Employee_Name + '%' OR Employee_Contactno LIKE '%' + @Employee_Contactno + '%' or Starting_Date LIKE '%' + @Starting_Date + '%'", conn);
             cmd1.Parameters.AddWithValue("@Employee_ID", textBox7.Text);
             cmd1.Parameters.AddWithValue("@Employee_Name", textBox7.Text);
             cmd1.Parameters.AddWithValue("@Employee_Contactno", textBox7.Text);
             cmd1.Parameters.AddWithValue("@Starting_Date", textBox7.Text);


             SqlDataAdapter da = new SqlDataAdapter(cmd1);
             DataTable dt = new DataTable();
             da.Fill(dt);

             dataGridView1.DataSource = dt;
             dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
             dataGridView1.DefaultCellStyle.Font = new Font("Arial", 12);*/
        }
        private DataTable search1()
        {
            string query1 = "Select Employee_ID,Employee_Name,Employee_Contactno,Employee_Address, Employee_Salary,Starting_Date from Employee ";
            query1 += "where Employee_ID like '%' + @parm1 + '%' ";
            query1 += "or Employee_Name like '%' + @parm1 + '%' ";
            query1 += "or Employee_Contactno like '%' + @parm1 + '%' ";
            query1 += "or Employee_Address like '%' + @parm1 + '%' ";
            query1 += "or Employee_Salary like '%' + @parm1 + '%' ";
            query1 += "or Starting_Date like '%' + @parm1 + '%'";

            string conn = "Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true";
            using (SqlConnection con1 = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand(query1, con1))
                {
                    cmd.Parameters.AddWithValue("@parm1", textBox7.Text);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                        return dt;
                    }
                }
            }

        }
        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyUp(object sender, KeyEventArgs e)
        {
            search1();
        }
    }
}

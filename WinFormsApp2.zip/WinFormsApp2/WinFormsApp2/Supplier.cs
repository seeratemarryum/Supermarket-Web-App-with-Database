﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp2
{
    public partial class Supplier : Form
    {
        public Supplier()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true");
        private void binddata()
        {
            SqlCommand cmd1 = new SqlCommand("Select Supplier_ID,Supplier_Brand_Name,Supplier_Email,Supplier_Contactno, Supplier_Address,Supplier_Owner_Name from Supplier", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.SelectCommand = cmd1;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Insert into Supplier(Supplier_ID, Supplier_Brand_Name, Supplier_Email, Supplier_Contactno, Supplier_Address,Supplier_Owner_Name)Values (@Supplier_ID, @Supplier_Brand_Name, @Supplier_Email, @Supplier_Contactno, @Supplier_Address, @Supplier_Owner_Name)", conn);
            cmd2.Parameters.AddWithValue("Supplier_ID", textBox1.Text);
            cmd2.Parameters.AddWithValue("Supplier_Brand_Name", textBox2.Text);
            cmd2.Parameters.AddWithValue("Supplier_Email", textBox3.Text);
            cmd2.Parameters.AddWithValue("Supplier_Contactno", textBox4.Text);
            cmd2.Parameters.AddWithValue("Supplier_Address", textBox5.Text);
            cmd2.Parameters.AddWithValue("Supplier_Owner_Name", textBox6.Text);
            cmd2.ExecuteNonQuery();
            conn.Close();
            binddata();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd3 = new SqlCommand("update Supplier Set Supplier_Brand_Name='" + textBox2.Text + "',Supplier_Email='" + textBox3.Text + "',Supplier_Contactno='" + textBox4.Text + "',Supplier_Address='" + textBox5.Text + "',Supplier_Owner_Name='" + textBox6.Text + "' where Supplier_ID='" + textBox1.Text + "'", conn);
            cmd3.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*SqlCommand cmd1 = new SqlCommand("SELECT * FROM Supplier WHERE Supplier_ID = @Supplier_ID OR Supplier_Brand_Name LIKE '%' + @Supplier_Brand_Name + '%' OR Supplier_Email LIKE '%' + @Supplier_Email + '%' OR Supplier_Contactno LIKE '%' + @Supplier_Contactno + '%' OR Supplier_Owner_Name LIKE '%' + @Supplier_Owner_Name + '%' ", conn);
            cmd1.Parameters.AddWithValue("@Supplier_ID", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Supplier_Brand_Name", textBox2.Text);
            cmd1.Parameters.AddWithValue("@Supplier_Email", textBox3.Text); 
            cmd1.Parameters.AddWithValue("@Supplier_Contactno", textBox4.Text); 
            cmd1.Parameters.AddWithValue("@Supplier_Owner_Name", textBox6.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);*/

            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Supplier WHERE Supplier_ID = @Supplier_ID OR Supplier_Brand_Name LIKE '%' + @Supplier_Brand_Name + '%' OR Supplier_Email LIKE '%' + @Supplier_Email + '%', OR Supplier_Contactno LIKE '%' + @Supplier_Contactno + '%'", conn);
            cmd1.Parameters.AddWithValue("@Supplier_ID", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Supplier_Brand_Name", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Supplier_Email", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Supplier_Contactno", textBox7.Text);



            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 12);
        }
        private DataTable search1()
        {
            string query1 = "Select Supplier_ID,Supplier_Brand_Name,Supplier_Email,Supplier_Contactno, Supplier_Address,Supplier_Owner_Name from Supplier ";
            query1 += "where Supplier_ID like '%' + @parm1 + '%' ";
            query1 += "or Supplier_Brand_Name like '%' + @parm1 + '%' ";
            query1 += "or Supplier_Email like '%' + @parm1 + '%' ";
            query1 += "or Supplier_Contactno like '%' + @parm1 + '%' ";
            query1 += "or Supplier_Address like '%' + @parm1 + '%' ";
            query1 += "or Supplier_Owner_Name like '%' + @parm1 + '%' ";

            string conn = "Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true";
            using (SqlConnection con1 = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand(query1, con1))
                {
                    cmd.Parameters.AddWithValue("@parm1", textBox7.Text);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                        return dt;
                    }
                }
            }

        }
        private void Supplier_Load(object sender, EventArgs e)
        {
            binddata();
            search1();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;
            DataGridViewRow selectedrow = dataGridView1.Rows[index];
            textBox1.Text = selectedrow.Cells[0].Value.ToString();
            textBox2.Text = selectedrow.Cells[1].Value.ToString();
            textBox3.Text = selectedrow.Cells[2].Value.ToString();
            textBox4.Text = selectedrow.Cells[3].Value.ToString();
            textBox5.Text = selectedrow.Cells[4].Value.ToString();
            textBox6.Text = selectedrow.Cells[5].Value.ToString();
        }

        private void textBox7_KeyUp(object sender, KeyEventArgs e)
        {
            search1();
        }
    }
}


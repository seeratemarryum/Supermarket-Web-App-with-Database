﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WinFormsApp2
{
    public partial class POrder : Form
    {
        public POrder()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true");
        private DataTable search1()
        {
            string query1 = "Select Order_ID,Sales_Date,Customer_ID,Total_Amount, Payment_Type,Paid,Balance from POrder ";
            query1 += "where Order_ID like '%' + @parm1 + '%' ";
            query1 += "or Sales_Date like '%' + @parm1 + '%' ";
            query1 += "or Customer_ID like '%' + @parm1 + '%' ";
            query1 += "or Total_Amount like '%' + @parm1 + '%' ";
            query1 += "or Payment_Type like '%' + @parm1 + '%' ";

            string conn = "Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true";
            using (SqlConnection con1 = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand(query1, con1))
                {
                    cmd.Parameters.AddWithValue("@parm1", textBox8.Text);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                        return dt;
                    }
                }
            }

        }
        private void POrder_Load(object sender, EventArgs e)
        {
            binddata();
            search1();
        }
        private void binddata()
        {
            SqlCommand cmd1 = new SqlCommand("Select Order_ID,Sales_Date,Customer_ID,Total_Amount, Payment_Type,Paid,Balance from POrder", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.SelectCommand = cmd1;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Insert into POrder(Order_ID, Sales_Date, Customer_ID, Total_Amount, Payment_Type, Paid,Balance)Values (@Order_ID, @Sales_Date, @Customer_ID, @Total_Amount, @Payment_Type, @Paid,@Balance)", conn);
            cmd2.Parameters.AddWithValue("Order_ID", textBox1.Text);
            cmd2.Parameters.AddWithValue("Sales_Date", textBox2.Text);
            cmd2.Parameters.AddWithValue("Customer_ID", textBox3.Text);
            cmd2.Parameters.AddWithValue("Total_Amount", textBox4.Text);
            cmd2.Parameters.AddWithValue("Payment_Type", textBox5.Text);
            cmd2.Parameters.AddWithValue("Paid", textBox6.Text);
            cmd2.Parameters.AddWithValue("Balance", textBox7.Text);
            cmd2.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM POrder WHERE Order_ID = @Order_ID OR Customer_ID LIKE '%' + @Customer_ID + '%' OR Payment_Type LIKE '%' + @Payment_Type + '%'", conn);
            cmd1.Parameters.AddWithValue("@Order_ID", textBox8.Text);
            cmd1.Parameters.AddWithValue("@Customer_ID", textBox8.Text);
            cmd1.Parameters.AddWithValue("@Payment_Type", textBox8.Text);


            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 12);
        }



        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd3 = new SqlCommand("update POrder Set Sales_Date='" + textBox2.Text + "',Customer_ID='" + textBox3.Text + "',Total_Amount='" + textBox4.Text + "',Payment_Type='" + textBox5.Text + "',Paid='" + textBox6.Text + "',Balance='" + textBox7.Text + "' where Order_ID='" + textBox1.Text + "'", conn);
            cmd3.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("Delete from POrder where Order_ID=@Order_ID", conn);
            cmd4.Parameters.AddWithValue("Order_ID", textBox1.Text);
            cmd4.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;
            DataGridViewRow selectedrow = dataGridView1.Rows[index];
            textBox1.Text = selectedrow.Cells[0].Value.ToString();
            textBox2.Text = selectedrow.Cells[1].Value.ToString();
            textBox3.Text = selectedrow.Cells[2].Value.ToString();
            textBox4.Text = selectedrow.Cells[3].Value.ToString();
            textBox5.Text = selectedrow.Cells[4].Value.ToString();
            textBox6.Text = selectedrow.Cells[5].Value.ToString();
            textBox7.Text = selectedrow.Cells[6].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_KeyUp(object sender, KeyEventArgs e)
        {
            search1();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }
    }
}

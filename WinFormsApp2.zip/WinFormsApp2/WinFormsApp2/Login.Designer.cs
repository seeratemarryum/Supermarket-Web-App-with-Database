﻿namespace WinFormsApp2
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            text_username = new TextBox();
            label2 = new Label();
            text_password = new TextBox();
            button_clear = new Button();
            Exit = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            label3 = new Label();
            comboBox1 = new ComboBox();
            button_login = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            panel1 = new Panel();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            button1 = new Button();
            panel2 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(447, 287);
            label1.Name = "label1";
            label1.Size = new Size(125, 26);
            label1.TabIndex = 0;
            label1.Text = "User Name";
            // 
            // text_username
            // 
            text_username.Location = new Point(604, 294);
            text_username.Name = "text_username";
            text_username.Size = new Size(195, 23);
            text_username.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 18F, FontStyle.Bold);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(447, 354);
            label2.Name = "label2";
            label2.Size = new Size(110, 26);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // text_password
            // 
            text_password.Location = new Point(604, 357);
            text_password.Name = "text_password";
            text_password.Size = new Size(195, 23);
            text_password.TabIndex = 4;
            text_password.TextChanged += text_password_TextChanged;
            // 
            // button_clear
            // 
            button_clear.BackColor = Color.DarkSlateGray;
            button_clear.FlatStyle = FlatStyle.Flat;
            button_clear.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_clear.ForeColor = Color.White;
            button_clear.Location = new Point(507, 437);
            button_clear.Name = "button_clear";
            button_clear.Size = new Size(70, 29);
            button_clear.TabIndex = 5;
            button_clear.Text = "Clear";
            button_clear.UseVisualStyleBackColor = false;
            button_clear.Click += button_clear_Click;
            // 
            // Exit
            // 
            Exit.BackColor = Color.DarkSlateGray;
            Exit.FlatStyle = FlatStyle.Flat;
            Exit.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Exit.ForeColor = Color.White;
            Exit.Location = new Point(430, 437);
            Exit.Name = "Exit";
            Exit.Size = new Size(71, 29);
            Exit.TabIndex = 6;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = false;
            Exit.Click += Exit_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(565, 107);
            label3.Name = "label3";
            label3.Size = new Size(130, 44);
            label3.TabIndex = 8;
            label3.Text = "LOGIN";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox1.ForeColor = Color.DarkSlateGray;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Employee", "Supervisor" });
            comboBox1.Location = new Point(604, 223);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(195, 27);
            comboBox1.TabIndex = 9;
            comboBox1.Text = "Select Role";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button_login
            // 
            button_login.BackColor = Color.DarkSlateGray;
            button_login.Cursor = Cursors.Hand;
            button_login.FlatStyle = FlatStyle.Flat;
            button_login.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button_login.ForeColor = Color.White;
            button_login.Location = new Point(605, 432);
            button_login.Name = "button_login";
            button_login.Size = new Size(195, 34);
            button_login.TabIndex = 2;
            button_login.Text = "Login";
            button_login.UseVisualStyleBackColor = false;
            button_login.Click += button1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Dock = DockStyle.Left;
            panel1.ForeColor = Color.DarkSlateGray;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(296, 587);
            panel1.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Stencil", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(35, 282);
            label6.Name = "label6";
            label6.Size = new Size(196, 32);
            label6.TabIndex = 13;
            label6.Text = "APPLICATION";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Stencil", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(17, 233);
            label5.Name = "label5";
            label5.Size = new Size(262, 32);
            label5.TabIndex = 12;
            label5.Text = "TO SUPERMARKET";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Stencil", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(69, 185);
            label4.Name = "label4";
            label4.Size = new Size(143, 32);
            label4.TabIndex = 11;
            label4.Text = "WELCOME";
            // 
            // button1
            // 
            button1.BackColor = Color.DarkSlateGray;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.ImageAlign = ContentAlignment.TopRight;
            button1.Location = new Point(676, 0);
            button1.Name = "button1";
            button1.Size = new Size(52, 29);
            button1.TabIndex = 11;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_2;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateGray;
            panel2.Controls.Add(button1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(296, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(723, 27);
            panel2.TabIndex = 12;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnableAllowFocusChange;
            BackColor = Color.White;
            ClientSize = new Size(1019, 587);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(Exit);
            Controls.Add(button_clear);
            Controls.Add(text_password);
            Controls.Add(label2);
            Controls.Add(button_login);
            Controls.Add(text_username);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            Load += Login_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox text_username;
        private Label label2;
        private TextBox text_password;
        private Button button_clear;
        private Button Exit;
        private ContextMenuStrip contextMenuStrip1;
        private Label label3;
        private ComboBox comboBox1;
        private Button button_login;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Panel panel1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Button button1;
        private Panel panel2;
    }
}
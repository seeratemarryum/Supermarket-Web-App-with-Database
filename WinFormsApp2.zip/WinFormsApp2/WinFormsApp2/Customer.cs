using System.Data;
using System.Data.SqlClient;
namespace WinFormsApp2
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();

        }
        SqlConnection conn = new SqlConnection("Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true ");

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void binddata()
        {
            SqlCommand cmd1 = new SqlCommand("Select Customer_ID,Customer_Name,Customer_Phno,Customer_Address, Customer_CNIC,Customer_Email from Customer", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.SelectCommand = cmd1;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            binddata();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Insert into Customer(Customer_ID, Customer_Name, Customer_Phno, Customer_Address, Customer_CNIC, Customer_Email)Values (@Customer_ID, @Customer_Name, @Customer_Phno, @Customer_Address, @Customer_CNIC, @Customer_Email)", conn);
            cmd2.Parameters.AddWithValue("Customer_ID", textBox1.Text);
            cmd2.Parameters.AddWithValue("Customer_Name", textBox2.Text);
            cmd2.Parameters.AddWithValue("Customer_Phno", textBox3.Text);
            cmd2.Parameters.AddWithValue("Customer_Address", textBox4.Text);
            cmd2.Parameters.AddWithValue("Customer_CNIC", textBox5.Text);
            cmd2.Parameters.AddWithValue("Customer_Email", textBox6.Text);
            cmd2.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;
            DataGridViewRow selectedrow = dataGridView1.Rows[index];
            textBox1.Text = selectedrow.Cells[0].Value.ToString();
            textBox2.Text = selectedrow.Cells[1].Value.ToString();
            textBox3.Text = selectedrow.Cells[2].Value.ToString();
            textBox4.Text = selectedrow.Cells[3].Value.ToString();
            textBox5.Text = selectedrow.Cells[4].Value.ToString();
            textBox6.Text = selectedrow.Cells[5].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            //  SqlCommand cmd3 = new SqlCommand("Update Customer Set frame=@Customer_Name, @Customer_Phno, @Customer_Address, @Customer_CNIC, @Customer_Email where Customer_ID=@Customer_ID", conn);

            SqlCommand cmd3 = new SqlCommand("update Customer Set Customer_Name='" + textBox2.Text + "',Customer_Phno='" + textBox3.Text + "',Customer_Address='" + textBox4.Text + "',Customer_CNIC='" + textBox5.Text + "',Customer_Email='" + textBox6.Text + "' where Customer_ID='" + textBox1.Text + "'", conn);

            // cmd3.Parameters.AddWithValue("Customer_ID", textBox1.Text);
            //cmd3.Parameters.AddWithValue("Customer_Name", textBox2.Text);
            //cmd3.Parameters.AddWithValue("Customer_Phno", textBox3.Text);
            //cmd3.Parameters.AddWithValue("Customer_Address", textBox4.Text);
            //cmd3.Parameters.AddWithValue("Customer_CNIC", textBox5.Text);
            //cmd3.Parameters.AddWithValue("Customer_Email", textBox6.Text);

            cmd3.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("Delete from Customer where Customer_ID=@Customer_ID", conn);
            cmd4.Parameters.AddWithValue("Customer_ID", textBox1.Text);
            cmd4.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Customer WHERE Customer_ID = @Customer_ID OR Customer_Email LIKE '%' + @Customer_Email + '%' OR Customer_Name LIKE '%' + @Customer_Name + '%' OR Customer_Phno LIKE '%' + @Customer_Phno ", conn);
            cmd1.Parameters.AddWithValue("@Customer_ID", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Customer_Name", textBox2.Text);
            cmd1.Parameters.AddWithValue("@Customer_Phno", textBox3.Text);
            cmd1.Parameters.AddWithValue("@Customer_Email", textBox6.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 12);
        }


        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("Select Customer_ID,Customer_Name,Customer_Phno,Customer_Address, Customer_CNIC,Customer_Email from Customer where Customer_Name Like @Customer_Name+'%' ", conn);
            cmd1.Parameters.AddWithValue("Customer_Name", textBox7.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.SelectCommand = cmd1;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);
        }

        private void button5_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox7_Enter(object sender, EventArgs e)
        {

        }
        private DataTable search1()
        {
            string query1 = "Select Customer_ID,Customer_Name,Customer_Phno,Customer_Address, Customer_CNIC,Customer_Email from Customer ";
            query1 += "where Customer_ID like '%' + @parm1 + '%' ";
            query1 += "or Customer_Name like '%' + @parm1 + '%' ";
            query1 += "or Customer_Phno like '%' + @parm1 + '%' ";
            query1 += "or Customer_Address like '%' + @parm1 + '%' ";
            query1 += "or Customer_CNIC like '%' + @parm1 + '%' ";
            query1 += "or Customer_Email like '%' + @parm1 + '%'";

            string conn = "Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true";
            using (SqlConnection con1 = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand(query1, con1))
                {
                    cmd.Parameters.AddWithValue("@parm1", textBox7.Text);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                        return dt;
                    }
                }
            }

        }
        private void textBox7_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Customer WHERE Customer_ID = @Customer_ID OR Customer_Name LIKE '%' + @Customer_Name + '%' OR Customer_Phno LIKE '%' + @Customer_Phno + '%' or Customer_CNIC LIKE '%' + @Customer_CNIC + '%'", conn);
            cmd1.Parameters.AddWithValue("@Customer_ID", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Customer_Name", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Customer_Phno", textBox7.Text);
            cmd1.Parameters.AddWithValue("@Customer_CNIC", textBox7.Text);


            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 12);


        }

        private void textBox7_KeyUp(object sender, KeyEventArgs e)
        {
            search1();
        }
    }
}

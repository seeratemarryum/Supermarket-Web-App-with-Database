﻿namespace WinFormsApp2
{
    partial class SupervisorDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupervisorDashboard));
            leftpanel = new Panel();
            button1 = new Button();
            label1 = new Label();
            button6 = new Button();
            pictureBox1 = new PictureBox();
            button5 = new Button();
            button4 = new Button();
            button2 = new Button();
            button3 = new Button();
            panelhead = new Panel();
            button7 = new Button();
            mainpanel = new Panel();
            label8 = new Label();
            leftpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelhead.SuspendLayout();
            mainpanel.SuspendLayout();
            SuspendLayout();
            // 
            // leftpanel
            // 
            leftpanel.BackColor = Color.DarkSlateGray;
            leftpanel.Controls.Add(button1);
            leftpanel.Controls.Add(label1);
            leftpanel.Controls.Add(button6);
            leftpanel.Controls.Add(pictureBox1);
            leftpanel.Controls.Add(button5);
            leftpanel.Controls.Add(button4);
            leftpanel.Controls.Add(button2);
            leftpanel.Controls.Add(button3);
            leftpanel.Dock = DockStyle.Left;
            leftpanel.Location = new Point(0, 0);
            leftpanel.Name = "leftpanel";
            leftpanel.Size = new Size(312, 708);
            leftpanel.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkSlateGray;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.FlatAppearance.BorderColor = Color.White;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(12, 563);
            button1.Name = "button1";
            button1.Size = new Size(272, 59);
            button1.TabIndex = 73;
            button1.Text = "      EMPLOYEE";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DarkSlateGray;
            label1.Font = new Font("Monotype Corsiva", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(47, 165);
            label1.Name = "label1";
            label1.Size = new Size(195, 25);
            label1.TabIndex = 72;
            label1.Text = "Supervisor Dashboard";
            // 
            // button6
            // 
            button6.BackColor = Color.DarkSlateGray;
            button6.FlatAppearance.BorderColor = Color.White;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Image = (Image)resources.GetObject("button6.Image");
            button6.ImageAlign = ContentAlignment.MiddleLeft;
            button6.Location = new Point(12, 487);
            button6.Name = "button6";
            button6.Size = new Size(294, 54);
            button6.TabIndex = 5;
            button6.Text = "INVOICE";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.InitialImage = null;
            pictureBox1.Location = new Point(47, 20);
            pictureBox1.Margin = new Padding(0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(186, 145);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button5
            // 
            button5.BackColor = Color.DarkSlateGray;
            button5.FlatAppearance.BorderColor = Color.White;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(12, 422);
            button5.Name = "button5";
            button5.Size = new Size(294, 54);
            button5.TabIndex = 4;
            button5.Text = "SUPPLIER";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.DarkSlateGray;
            button4.FlatAppearance.BorderColor = Color.White;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(12, 357);
            button4.Name = "button4";
            button4.Size = new Size(294, 59);
            button4.TabIndex = 3;
            button4.Text = "PRODUCT";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkSlateGray;
            button2.FlatAppearance.BorderColor = Color.White;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(12, 241);
            button2.Name = "button2";
            button2.Size = new Size(294, 47);
            button2.TabIndex = 1;
            button2.Text = "CUSTOMER";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkSlateGray;
            button3.FlatAppearance.BorderColor = Color.White;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(12, 294);
            button3.Name = "button3";
            button3.Size = new Size(294, 55);
            button3.TabIndex = 2;
            button3.Text = "ORDER";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // panelhead
            // 
            panelhead.BackColor = Color.DarkSlateGray;
            panelhead.Controls.Add(button7);
            panelhead.Dock = DockStyle.Top;
            panelhead.Location = new Point(312, 0);
            panelhead.Name = "panelhead";
            panelhead.Size = new Size(1222, 33);
            panelhead.TabIndex = 1;
            // 
            // button7
            // 
            button7.BackColor = Color.DarkSlateGray;
            button7.FlatAppearance.BorderColor = Color.White;
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.White;
            button7.ImageAlign = ContentAlignment.MiddleLeft;
            button7.Location = new Point(1165, 0);
            button7.Name = "button7";
            button7.Size = new Size(45, 33);
            button7.TabIndex = 6;
            button7.Text = "x";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // mainpanel
            // 
            mainpanel.Controls.Add(label8);
            mainpanel.Dock = DockStyle.Fill;
            mainpanel.Location = new Point(312, 33);
            mainpanel.Name = "mainpanel";
            mainpanel.Size = new Size(1222, 675);
            mainpanel.TabIndex = 2;
            mainpanel.Paint += panel3_Paint;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.White;
            label8.Font = new Font("Monotype Corsiva", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.DarkSlateGray;
            label8.Location = new Point(235, 214);
            label8.Name = "label8";
            label8.Size = new Size(572, 57);
            label8.TabIndex = 71;
            label8.Text = "WELCOME TO HSM MART";
            label8.Click += label8_Click;
            // 
            // SupervisorDashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1534, 708);
            Controls.Add(mainpanel);
            Controls.Add(panelhead);
            Controls.Add(leftpanel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "SupervisorDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main_Form";
            leftpanel.ResumeLayout(false);
            leftpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelhead.ResumeLayout(false);
            mainpanel.ResumeLayout(false);
            mainpanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel leftpanel;
        private Panel panelhead;
        private Panel mainpanel;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button6;
        private PictureBox pictureBox1;
        private Button button7;
        private Label label8;
        private Label label1;
        private Button button1;
    }
}
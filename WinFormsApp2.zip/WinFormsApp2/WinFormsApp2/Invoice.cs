﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace WinFormsApp2
{
    public partial class Invoice : Form
    {
        public Invoice()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true");
        private void Invoice_Load(object sender, EventArgs e)
        {
            binddata();
            search1();

        }

        private DataTable search1()
        {
            string query1 = "Select Invoice_ID,Order_ID,Product_ID,Product_Quantity,Customer_ID from Invoice ";
            query1 += "where Invoice_ID like '%' + @parm1 + '%' ";
            query1 += "or Order_ID like '%' + @parm1 + '%' ";
            query1 += "or Product_ID like '%' + @parm1 + '%' ";
            query1 += "or Product_Quantity like '%' + @parm1 + '%' ";
            query1 += "or Customer_ID like '%' + @parm1 + '%' ";

            string conn = "Data source=DESKTOP-LCKB76G\\MSSQLSERVER01;initial catalog=SuperMarketDatabase;integrated security=true";
            using (SqlConnection con1 = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand(query1, con1))
                {
                    cmd.Parameters.AddWithValue("@parm1", textBox6.Text);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                        return dt;
                    }
                }
            }

        }
        private void binddata()
        {
            SqlCommand cmd1 = new SqlCommand("Select Invoice_ID,Order_ID,Product_ID,Product_Quantity,Customer_ID from Invoice", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.SelectCommand = cmd1;
            DataTable dt = new DataTable();
            dt.Clear();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("arial", 12);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Insert into Invoice(Invoice_ID,Order_ID,Product_ID,Product_Quantity,Customer_ID)Values (@Invoice_ID,@Order_ID,@Product_ID,@Product_Quantity,@Customer_ID)", conn);
            cmd2.Parameters.AddWithValue("Invoice_ID", textBox1.Text);
            cmd2.Parameters.AddWithValue("Order_ID", textBox2.Text);
            cmd2.Parameters.AddWithValue("Product_ID", textBox3.Text);
            cmd2.Parameters.AddWithValue("Product_Quantity", textBox4.Text);
            cmd2.Parameters.AddWithValue("Customer_ID", textBox5.Text);
            cmd2.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;
            DataGridViewRow selectedrow = dataGridView1.Rows[index];
            textBox1.Text = selectedrow.Cells[0].Value.ToString();
            textBox2.Text = selectedrow.Cells[1].Value.ToString();
            textBox3.Text = selectedrow.Cells[2].Value.ToString();
            textBox4.Text = selectedrow.Cells[3].Value.ToString();
            textBox5.Text = selectedrow.Cells[4].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            //  SqlCommand cmd3 = new SqlCommand("Update Customer Set frame=@Customer_Name, @Customer_Phno, @Customer_Address, @Customer_CNIC, @Customer_Email where Customer_ID=@Customer_ID", conn);

            SqlCommand cmd3 = new SqlCommand("Update Invoice Set Order_ID='" + textBox2.Text + "',Product_ID='" + textBox3.Text + "',Product_Quantity='" + textBox4.Text + "',Customer_ID='" + textBox5.Text + "'  where Invoice_ID='" + textBox1.Text + "'", conn);
            cmd3.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd4 = new SqlCommand("Delete from Invoice where Invoice_ID=@Invoice_ID", conn);
            cmd4.Parameters.AddWithValue("Invoice_ID", textBox1.Text);
            cmd4.ExecuteNonQuery();
            conn.Close();
            binddata();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Invoice WHERE Invoice_ID = @Invoice_ID OR Order_ID = @Order_ID OR Product_ID = @Product_ID OR Customer_ID LIKE '%' + @Customer_ID + '%'", conn);
            cmd1.Parameters.AddWithValue("@Invoice_ID", textBox6.Text);
            cmd1.Parameters.AddWithValue("@Order_ID", textBox6.Text);
            cmd1.Parameters.AddWithValue("@Product_ID", textBox6.Text);
            cmd1.Parameters.AddWithValue("@Customer_ID", textBox6.Text);


            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 12, FontStyle.Bold);
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 12);

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_KeyUp(object sender, KeyEventArgs e)
        {
            search1();

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_KeyUp(object sender, KeyEventArgs e)
        {
            search1();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WinFormsApp2
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-LCKB76G\\MSSQLSERVER01;Initial Catalog=SuperMarketDatabase;Integrated Security=True");

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

           string selectedRole = comboBox1.SelectedItem as string;

    if (string.IsNullOrEmpty(selectedRole))
    {
        MessageBox.Show("Please select a role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
    }

    try
    {
        using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-LCKB76G\\MSSQLSERVER01;Initial Catalog=SuperMarketDatabase;Integrated Security=True"))
        {
            con.Open();

            string query = "SELECT * FROM Login WHERE Username=@username AND Password=@password";
            
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@username", text_username.Text);
                cmd.Parameters.AddWithValue("@password", text_password.Text);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dtable = new DataTable();
                sda.Fill(dtable);

                if (dtable.Rows.Count > 0)
                {
                    if (selectedRole.Equals("Employee", StringComparison.OrdinalIgnoreCase))
                    {
                        EmployeeDashboard employeeDashboard = new EmployeeDashboard();
                        employeeDashboard.Show();
                        this.Hide();
                    }
                    else if (selectedRole.Equals("Supervisor", StringComparison.OrdinalIgnoreCase))
                    {
                        SupervisorDashboard supervisorDashboard = new SupervisorDashboard();
                        supervisorDashboard.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid login details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    text_username.Clear();
                    text_password.Clear();
                    text_username.Focus();
                }
            }
        }
    }
    catch (SqlException ex)
    {
        MessageBox.Show("Database error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            text_username.Clear();
            text_password.Clear();

            text_username.Focus();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("Do you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Show();

            }
        }

        private void text_password_TextChanged(object sender, EventArgs e)
        {
            text_password.PasswordChar = '*';

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
